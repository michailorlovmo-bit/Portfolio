"""
Simple test script for the Task Management API
Run this after starting the API server to test basic functionality
"""

import requests
import json

BASE_URL = "http://localhost:8000"

def print_response(response):
    """Pretty print response"""
    print(f"Status Code: {response.status_code}")
    try:
        print(f"Response: {json.dumps(response.json(), indent=2)}")
    except:
        print(f"Response: {response.text}")
    print("-" * 50)

def main():
    print("Testing Task Management API")
    print("=" * 50)

    # Test 1: Root endpoint
    print("\n1. Testing root endpoint...")
    response = requests.get(f"{BASE_URL}/")
    print_response(response)

    # Test 2: Register user
    print("\n2. Registering new user...")
    user_data = {
        "username": "testuser",
        "email": "test@example.com",
        "password": "password123"
    }
    response = requests.post(f"{BASE_URL}/api/register", json=user_data)
    print_response(response)

    # Test 3: Login
    print("\n3. Logging in...")
    login_data = {
        "username": "testuser",
        "password": "password123"
    }
    response = requests.post(f"{BASE_URL}/api/login", json=login_data)
    print_response(response)

    if response.status_code == 200:
        token = response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}

        # Test 4: Get current user
        print("\n4. Getting current user...")
        response = requests.get(f"{BASE_URL}/api/users/me", headers=headers)
        print_response(response)

        # Test 5: Create task
        print("\n5. Creating a new task...")
        task_data = {
            "title": "Complete API documentation",
            "description": "Write comprehensive README and test the API endpoints",
            "status": "pending",
            "priority": "high",
            "due_date": "2024-12-31"
        }
        response = requests.post(f"{BASE_URL}/api/tasks", json=task_data, headers=headers)
        print_response(response)

        task_id = None
        if response.status_code == 201:
            task_id = response.json()["id"]

            # Test 6: Get all tasks
            print("\n6. Getting all tasks...")
            response = requests.get(f"{BASE_URL}/api/tasks", headers=headers)
            print_response(response)

            # Test 7: Get specific task
            print(f"\n7. Getting task {task_id}...")
            response = requests.get(f"{BASE_URL}/api/tasks/{task_id}", headers=headers)
            print_response(response)

            # Test 8: Update task
            print(f"\n8. Updating task {task_id}...")
            update_data = {
                "status": "in_progress",
                "priority": "medium"
            }
            response = requests.put(f"{BASE_URL}/api/tasks/{task_id}", json=update_data, headers=headers)
            print_response(response)

            # Test 9: Get task statistics
            print("\n9. Getting task statistics...")
            response = requests.get(f"{BASE_URL}/api/tasks/stats/summary", headers=headers)
            print_response(response)

            # Test 10: Delete task
            print(f"\n10. Deleting task {task_id}...")
            response = requests.delete(f"{BASE_URL}/api/tasks/{task_id}", headers=headers)
            print_response(response)

    print("\n" + "=" * 50)
    print("Testing completed!")
    print("\nNote: If you see errors about user already existing,")
    print("delete tasks.db and restart the server to reset the database.")

if __name__ == "__main__":
    try:
        main()
    except requests.exceptions.ConnectionError:
        print("Error: Could not connect to the API server.")
        print("Make sure the server is running at http://localhost:8000")
    except Exception as e:
        print(f"Error: {e}")
