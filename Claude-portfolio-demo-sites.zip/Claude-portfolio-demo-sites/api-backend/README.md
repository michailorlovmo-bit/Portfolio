# Task Management REST API

A RESTful API for task management built with FastAPI and Python. Features JWT authentication, full CRUD operations, input validation, and automatic API documentation.

## Features

### Core Features
- **User Authentication**: JWT-based authentication with token expiration
- **Task Management**: Full CRUD operations for tasks
- **User Management**: User registration and profile access
- **Input Validation**: Pydantic models for request/response validation
- **Filtering**: Filter tasks by status and priority
- **Statistics**: Task summary and statistics endpoint
- **Auto Documentation**: Swagger UI and ReDoc

### Security
- Password hashing with bcrypt
- JWT tokens with expiration
- Protected endpoints with Bearer authentication
- CORS middleware for cross-origin requests

### API Documentation
- **Swagger UI**: Interactive API documentation at `/docs`
- **ReDoc**: Alternative documentation at `/redoc`
- **OpenAPI Schema**: Available at `/openapi.json`

## Tech Stack

- **FastAPI**: Modern, fast web framework
- **SQLite**: Lightweight database
- **Pydantic**: Data validation using Python type annotations
- **JWT**: JSON Web Tokens for authentication
- **Passlib**: Password hashing library
- **Uvicorn**: ASGI server

## Project Structure

```
api-backend/
├── main.py              # Main FastAPI application
├── tasks.db            # SQLite database (created on first run)
├── requirements.txt    # Python dependencies
├── models/             # Pydantic models (future)
├── routes/             # API routes (future)
└── utils/              # Utility functions (future)
```

## Setup and Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation Steps

1. **Navigate to project directory**
   ```bash
   cd api-backend
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   ```

3. **Activate virtual environment**
   ```bash
   # On Linux/Mac:
   source venv/bin/activate

   # On Windows:
   venv\Scripts\activate
   ```

4. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

5. **Run the application**
   ```bash
   python main.py
   ```

   Or with uvicorn directly:
   ```bash
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

6. **Access the API**
   - API Base URL: `http://localhost:8000`
   - Swagger Documentation: `http://localhost:8000/docs`
   - ReDoc Documentation: `http://localhost:8000/redoc`

## API Endpoints

### Authentication

#### Register User
```http
POST /api/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securepassword123"
}
```

**Response:**
```json
{
  "id": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "created_at": "2024-01-01T12:00:00"
}
```

#### Login
```http
POST /api/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "securepassword123"
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

### Users

#### Get Current User
```http
GET /api/users/me
Authorization: Bearer {token}
```

**Response:**
```json
{
  "id": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "created_at": "2024-01-01T12:00:00"
}
```

### Tasks

#### Create Task
```http
POST /api/tasks
Authorization: Bearer {token}
Content-Type: application/json

{
  "title": "Complete project documentation",
  "description": "Write comprehensive README and API docs",
  "status": "pending",
  "priority": "high",
  "due_date": "2024-12-31"
}
```

**Response:**
```json
{
  "id": 1,
  "title": "Complete project documentation",
  "description": "Write comprehensive README and API docs",
  "status": "pending",
  "priority": "high",
  "due_date": "2024-12-31",
  "user_id": 1,
  "created_at": "2024-01-01T12:00:00",
  "updated_at": "2024-01-01T12:00:00"
}
```

#### Get All Tasks
```http
GET /api/tasks
Authorization: Bearer {token}

# Optional query parameters:
# ?status=pending
# ?priority=high
```

**Response:**
```json
[
  {
    "id": 1,
    "title": "Complete project documentation",
    "description": "Write comprehensive README and API docs",
    "status": "pending",
    "priority": "high",
    "due_date": "2024-12-31",
    "user_id": 1,
    "created_at": "2024-01-01T12:00:00",
    "updated_at": "2024-01-01T12:00:00"
  }
]
```

#### Get Task by ID
```http
GET /api/tasks/{task_id}
Authorization: Bearer {token}
```

#### Update Task
```http
PUT /api/tasks/{task_id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "status": "in_progress",
  "priority": "high"
}
```

#### Delete Task
```http
DELETE /api/tasks/{task_id}
Authorization: Bearer {token}
```

**Response:** 204 No Content

#### Get Task Statistics
```http
GET /api/tasks/stats/summary
Authorization: Bearer {token}
```

**Response:**
```json
{
  "total": 10,
  "pending": 3,
  "in_progress": 4,
  "completed": 3
}
```

## Data Models

### User
- `id`: Integer (auto-generated)
- `username`: String (unique, 3-50 characters)
- `email`: String (unique, valid email)
- `password`: String (min 6 characters, hashed)
- `created_at`: Timestamp

### Task
- `id`: Integer (auto-generated)
- `title`: String (required, 1-200 characters)
- `description`: String (optional)
- `status`: Enum (`pending`, `in_progress`, `completed`)
- `priority`: Enum (`low`, `medium`, `high`)
- `due_date`: String (optional, ISO date format)
- `user_id`: Integer (foreign key)
- `created_at`: Timestamp
- `updated_at`: Timestamp

## Authentication Flow

1. **Register**: Create a new user account
2. **Login**: Receive JWT access token
3. **Use Token**: Include token in Authorization header for protected endpoints
   ```
   Authorization: Bearer {your_access_token}
   ```
4. **Token Expiry**: Tokens expire after 30 minutes (configurable)

## Testing the API

### Using cURL

```bash
# Register
curl -X POST http://localhost:8000/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123"}'

# Login
curl -X POST http://localhost:8000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"password123"}'

# Create Task (replace TOKEN with your actual token)
curl -X POST http://localhost:8000/api/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" \
  -d '{"title":"My Task","description":"Task description","status":"pending","priority":"medium"}'

# Get Tasks
curl -X GET http://localhost:8000/api/tasks \
  -H "Authorization: Bearer TOKEN"
```

### Using Python Requests

```python
import requests

BASE_URL = "http://localhost:8000"

# Register
response = requests.post(f"{BASE_URL}/api/register", json={
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
})
print(response.json())

# Login
response = requests.post(f"{BASE_URL}/api/login", json={
    "username": "testuser",
    "password": "password123"
})
token = response.json()["access_token"]

# Create Task
headers = {"Authorization": f"Bearer {token}"}
response = requests.post(f"{BASE_URL}/api/tasks", json={
    "title": "My Task",
    "description": "Task description",
    "status": "pending",
    "priority": "medium"
}, headers=headers)
print(response.json())

# Get Tasks
response = requests.get(f"{BASE_URL}/api/tasks", headers=headers)
print(response.json())
```

## Configuration

### Environment Variables

Create a `.env` file in the project root:

```env
SECRET_KEY=your-super-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30
DATABASE_URL=tasks.db
```

### Security Configuration

For production:
1. Change `SECRET_KEY` to a secure random string
2. Use environment variables for sensitive data
3. Enable HTTPS
4. Configure CORS properly
5. Use PostgreSQL instead of SQLite
6. Implement rate limiting
7. Add request logging

## Database

The application uses SQLite for simplicity. The database is automatically created on first run with the following tables:

- `users`: User accounts with authentication
- `tasks`: User tasks with relationships

### Migrations

For production, consider using Alembic for database migrations:

```bash
pip install alembic
alembic init migrations
```

## Error Handling

The API returns standard HTTP status codes:

- `200 OK`: Success
- `201 Created`: Resource created
- `204 No Content`: Success with no response body
- `400 Bad Request`: Invalid input
- `401 Unauthorized`: Authentication required or failed
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `422 Unprocessable Entity`: Validation error

Error responses include detailed messages:

```json
{
  "detail": "Username or email already registered"
}
```

## Performance

- Database connection pooling (for production)
- Indexed database queries
- Efficient query filtering
- JWT token caching

## Future Enhancements

- [ ] Task categories/tags
- [ ] Task sharing between users
- [ ] File attachments
- [ ] Notifications
- [ ] WebSocket support for real-time updates
- [ ] Rate limiting
- [ ] Pagination for large result sets
- [ ] Advanced search and filtering
- [ ] Task comments
- [ ] Activity logging

## Production Deployment

### Using Docker

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Using Gunicorn + Uvicorn

```bash
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

## License

MIT License - Free to use for portfolio and commercial projects.

## Portfolio Demo

This API demonstrates:
- RESTful API design principles
- JWT authentication implementation
- Database design and relationships
- Input validation and error handling
- API documentation with OpenAPI/Swagger
- Python async programming with FastAPI
- Security best practices
