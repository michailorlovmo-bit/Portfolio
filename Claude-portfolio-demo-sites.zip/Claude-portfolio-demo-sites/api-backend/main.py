from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional
from datetime import datetime, timedelta
import sqlite3
import jwt
from passlib.context import CryptContext
import os

# Configuration
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
DATABASE = "tasks.db"

# Initialize FastAPI app
app = FastAPI(
    title="Task Management API",
    description="A RESTful API for managing tasks with user authentication",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Database helper
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Initialize database
def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Tasks table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'pending',
            priority TEXT DEFAULT 'medium',
            due_date TEXT,
            user_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    conn.commit()
    conn.close()

# Pydantic models
class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=6)

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    created_at: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TaskCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    status: Optional[str] = Field(default="pending", pattern="^(pending|in_progress|completed)$")
    priority: Optional[str] = Field(default="medium", pattern="^(low|medium|high)$")
    due_date: Optional[str] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = None
    status: Optional[str] = Field(None, pattern="^(pending|in_progress|completed)$")
    priority: Optional[str] = Field(None, pattern="^(low|medium|high)$")
    due_date: Optional[str] = None

class TaskResponse(BaseModel):
    id: int
    title: str
    description: Optional[str]
    status: str
    priority: str
    due_date: Optional[str]
    user_id: int
    created_at: str
    updated_at: str

# Utility functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: int = payload.get("sub")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials"
            )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )

    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )

    return dict(user)

# Routes
@app.get("/", tags=["Root"])
def read_root():
    """API root endpoint"""
    return {
        "message": "Welcome to Task Management API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc"
    }

@app.post("/api/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED, tags=["Authentication"])
def register(user: UserCreate):
    """Register a new user"""
    conn = get_db()

    # Check if user exists
    existing_user = conn.execute(
        'SELECT id FROM users WHERE username = ? OR email = ?',
        (user.username, user.email)
    ).fetchone()

    if existing_user:
        conn.close()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email already registered"
        )

    # Create user
    password_hash = get_password_hash(user.password)
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
        (user.username, user.email, password_hash)
    )
    conn.commit()

    user_id = cursor.lastrowid
    new_user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()

    return dict(new_user)

@app.post("/api/login", response_model=Token, tags=["Authentication"])
def login(user: UserLogin):
    """Login and receive JWT token"""
    conn = get_db()
    db_user = conn.execute('SELECT * FROM users WHERE username = ?', (user.username,)).fetchone()
    conn.close()

    if not db_user or not verify_password(user.password, db_user['password_hash']):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )

    access_token = create_access_token(data={"sub": db_user['id']})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/users/me", response_model=UserResponse, tags=["Users"])
def read_users_me(current_user: dict = Depends(get_current_user)):
    """Get current user information"""
    return current_user

@app.get("/api/tasks", response_model=List[TaskResponse], tags=["Tasks"])
def get_tasks(
    status: Optional[str] = None,
    priority: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    """Get all tasks for the current user with optional filtering"""
    conn = get_db()

    query = 'SELECT * FROM tasks WHERE user_id = ?'
    params = [current_user['id']]

    if status:
        query += ' AND status = ?'
        params.append(status)

    if priority:
        query += ' AND priority = ?'
        params.append(priority)

    query += ' ORDER BY created_at DESC'

    tasks = conn.execute(query, params).fetchall()
    conn.close()

    return [dict(task) for task in tasks]

@app.post("/api/tasks", response_model=TaskResponse, status_code=status.HTTP_201_CREATED, tags=["Tasks"])
def create_task(task: TaskCreate, current_user: dict = Depends(get_current_user)):
    """Create a new task"""
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO tasks (title, description, status, priority, due_date, user_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (task.title, task.description, task.status, task.priority, task.due_date, current_user['id']))

    conn.commit()
    task_id = cursor.lastrowid

    new_task = conn.execute('SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    conn.close()

    return dict(new_task)

@app.get("/api/tasks/{task_id}", response_model=TaskResponse, tags=["Tasks"])
def get_task(task_id: int, current_user: dict = Depends(get_current_user)):
    """Get a specific task by ID"""
    conn = get_db()
    task = conn.execute('SELECT * FROM tasks WHERE id = ? AND user_id = ?',
                       (task_id, current_user['id'])).fetchone()
    conn.close()

    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )

    return dict(task)

@app.put("/api/tasks/{task_id}", response_model=TaskResponse, tags=["Tasks"])
def update_task(task_id: int, task_update: TaskUpdate, current_user: dict = Depends(get_current_user)):
    """Update a task"""
    conn = get_db()

    # Check if task exists and belongs to user
    existing_task = conn.execute('SELECT * FROM tasks WHERE id = ? AND user_id = ?',
                                 (task_id, current_user['id'])).fetchone()

    if not existing_task:
        conn.close()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )

    # Build update query
    update_fields = []
    params = []

    if task_update.title is not None:
        update_fields.append('title = ?')
        params.append(task_update.title)

    if task_update.description is not None:
        update_fields.append('description = ?')
        params.append(task_update.description)

    if task_update.status is not None:
        update_fields.append('status = ?')
        params.append(task_update.status)

    if task_update.priority is not None:
        update_fields.append('priority = ?')
        params.append(task_update.priority)

    if task_update.due_date is not None:
        update_fields.append('due_date = ?')
        params.append(task_update.due_date)

    update_fields.append('updated_at = CURRENT_TIMESTAMP')

    if not update_fields:
        conn.close()
        return dict(existing_task)

    params.extend([task_id, current_user['id']])

    query = f"UPDATE tasks SET {', '.join(update_fields)} WHERE id = ? AND user_id = ?"
    conn.execute(query, params)
    conn.commit()

    updated_task = conn.execute('SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    conn.close()

    return dict(updated_task)

@app.delete("/api/tasks/{task_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Tasks"])
def delete_task(task_id: int, current_user: dict = Depends(get_current_user)):
    """Delete a task"""
    conn = get_db()

    # Check if task exists and belongs to user
    task = conn.execute('SELECT * FROM tasks WHERE id = ? AND user_id = ?',
                       (task_id, current_user['id'])).fetchone()

    if not task:
        conn.close()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )

    conn.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()

    return None

@app.get("/api/tasks/stats/summary", tags=["Tasks"])
def get_task_stats(current_user: dict = Depends(get_current_user)):
    """Get task statistics for the current user"""
    conn = get_db()

    total = conn.execute('SELECT COUNT(*) as count FROM tasks WHERE user_id = ?',
                        (current_user['id'],)).fetchone()['count']

    pending = conn.execute('SELECT COUNT(*) as count FROM tasks WHERE user_id = ? AND status = "pending"',
                          (current_user['id'],)).fetchone()['count']

    in_progress = conn.execute('SELECT COUNT(*) as count FROM tasks WHERE user_id = ? AND status = "in_progress"',
                               (current_user['id'],)).fetchone()['count']

    completed = conn.execute('SELECT COUNT(*) as count FROM tasks WHERE user_id = ? AND status = "completed"',
                            (current_user['id'],)).fetchone()['count']

    conn.close()

    return {
        "total": total,
        "pending": pending,
        "in_progress": in_progress,
        "completed": completed
    }

# Initialize database on startup
@app.on_event("startup")
def startup_event():
    if not os.path.exists(DATABASE):
        init_db()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
